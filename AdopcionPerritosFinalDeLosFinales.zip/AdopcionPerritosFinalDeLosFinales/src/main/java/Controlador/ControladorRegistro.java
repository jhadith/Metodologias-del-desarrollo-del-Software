package Controlador;

import Modelo.ModeloRegistro;
import Vista.VistaRegistro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import org.bson.Document;
import Modelo.ConexionMongo;
import Vista.VistaInicioSesion;
import Vista.VistaSolicitudes;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.event.ListSelectionListener;
import java.nio.file.*;
import java.io.File;
import java.text.Normalizer;

public class ControladorRegistro implements ActionListener {

    private final Path baseImgDir = Paths.get(System.getProperty("user.dir"), "imagenes_mascotas");
    private ModeloRegistro modelo;
    private VistaRegistro view;
    private ConexionMongo mongo;

    public ControladorRegistro(VistaRegistro view) {
        this.view = view;
        this.mongo = new ConexionMongo("RegistroMascotas");

        this.view.btnSave1.addActionListener(this);
        this.view.btnClean1.addActionListener(this);
        this.view.btnSolicitudes.addActionListener(this);
        this.view.btnUpdateUribe.addActionListener(this);
        this.view.btnImagen.addActionListener(this);

        // Listener: al seleccionar fila, muestra los datos en los campos
        this.view.tablaDatos1.getSelectionModel().addListSelectionListener((ListSelectionListener) e -> {
            if (!e.getValueIsAdjusting()) {
                int row = view.tablaDatos1.getSelectedRow();
                if (row >= 0) {
                    mostrarDatosMascotaEnCampos(row);
                }
            }
        });
        this.view.btnExit2.addActionListener(this);
    }

    public void iniciarVista() {
        view.setVisible(true);
        limpiarCampos();
        cargarRegistrosTabla();
    }

    // Muestra los datos de la mascota seleccionada en los campos
    private void mostrarDatosMascotaEnCampos(int row) {
        String nombre = String.valueOf(view.tablaDatos1.getValueAt(row, 0));
        String genero = String.valueOf(view.tablaDatos1.getValueAt(row, 1));
        String edad = String.valueOf(view.tablaDatos1.getValueAt(row, 2));
        String descripcion = String.valueOf(view.tablaDatos1.getValueAt(row, 3));

        view.txtNombre1.setText(nombre);
        view.spAge1.setValue(Integer.parseInt(edad));
        view.txtDescripcion1.setText(descripcion);

        if (genero.equalsIgnoreCase("Macho")) {
            view.radioMacho1.setSelected(true);
            view.radioHembra1.setSelected(false);
        } else if (genero.equalsIgnoreCase("Hembra")) {
            view.radioMacho1.setSelected(false);
            view.radioHembra1.setSelected(true);
        } else {
            view.radioMacho1.setSelected(false);
            view.radioHembra1.setSelected(false);
        }
    }

    private void limpiarCampos() {
        view.txtNombre1.setText("");
        view.txtDescripcion1.setText("");
        view.radioMacho1.setSelected(false);
        view.radioHembra1.setSelected(false);
        view.spAge1.setValue(0);
        view.tablaDatos1.clearSelection();
    }

    private void guardarRegistro() {
        String nombre = view.txtNombre1.getText();
        String descripcion = view.txtDescripcion1.getText();
        String genero = view.radioMacho1.isSelected() ? "Macho" : view.radioHembra1.isSelected() ? "Hembra" : "";
        String edad = view.spAge1.getValue().toString();
        int edadInt;
        try {
            edadInt = Integer.parseInt(edad);
            if (edadInt < 0 || edadInt > 25) {
                JOptionPane.showMessageDialog(view, "La edad debe estar entre 0 y 25 años.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Edad no valida.");
            return;
        }

        if (nombre.isEmpty() || genero.isEmpty() || descripcion.isEmpty() || edad.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Por favor, complete todos los campos.");
            return;
        }
        String nombreSan = normalizar(nombre);
        Path carpetaMascota = baseImgDir.resolve(nombreSan);
        File carpeta = carpetaMascota.toFile();
        File[] archivos = carpeta.listFiles((dir, name) -> {
            String lower = name.toLowerCase();
            return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".gif");
        });

        if (archivos == null || archivos.length == 0) {
            JOptionPane.showMessageDialog(view, "Debe agregar una fotografia antes de guardar.");
            return;
        }

        Document filtro = new Document("Nombre", nombre);
        if (mongo.buscar(filtro) != null) {
            JOptionPane.showMessageDialog(view, "Ya existe un registro con este nombre.", "Registro duplicado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document nuevoRegistro = new Document("Nombre", nombre)
                .append("Genero", genero)
                .append("Edad", edad)
                .append("Descripcion", descripcion);

        if (mongo.guardar(nuevoRegistro)) {
            JOptionPane.showMessageDialog(view, "Registro de mascota guardado correctamente.", "Registro completado", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos(); // Limpieza después de guardar
            cargarRegistrosTabla();
        } else {
            JOptionPane.showMessageDialog(view, "Error al registrar la mascota.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        exportarRegistrosXML();
    }

    private void exportarRegistrosXML() {
        List<Document> registros = mongo.lista(new Document()); // Obtiene lista de mascotas
        StringBuilder xml = new StringBuilder();
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        xml.append("<Mascotas>\n");
        for (Document doc : registros) {
            xml.append("  <Mascota>\n");
            xml.append("    <Nombre>").append(doc.getString("Nombre")).append("</Nombre>\n");
            xml.append("    <Genero>").append(doc.getString("Genero")).append("</Genero>\n");
            xml.append("    <Edad>").append(doc.getString("Edad")).append("</Edad>\n");
            xml.append("    <Descripcion>").append(doc.getString("Descripcion")).append("</Descripcion>\n");
            // Agrega aquí otros campos si los tienes
            xml.append("  </Mascota>\n");
        }
        xml.append("</Mascotas>\n");

        // GUARDAR ARCHIVO XML EN DISCO
        try {
            Files.write(Paths.get("mascotas.xml"), xml.toString().getBytes("UTF-8"));
            JOptionPane.showMessageDialog(view, "Archivo XML generado correctamente como mascotas.xml");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(view, "Error generando XML: " + ex.getMessage());
        }
    }

    private void actualizarRegistro() {
        int filaSeleccionada = view.tablaDatos1.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(view, "Seleccione un registro de la tabla para actualizar.");
            return;
        }

        String nombreAntiguo = view.tablaDatos1.getValueAt(filaSeleccionada, 0).toString();
        String nombreNuevo = view.txtNombre1.getText();
        String descripcionNueva = view.txtDescripcion1.getText();
        String generoNuevo = view.radioMacho1.isSelected() ? "Macho" : view.radioHembra1.isSelected() ? "Hembra" : "";
        String edadNueva = view.spAge1.getValue().toString();
        int edadInt;
        try {
            edadInt = Integer.parseInt(edadNueva);
            if (edadInt < 0 || edadInt > 25) {
                JOptionPane.showMessageDialog(view, "La edad debe estar entre 0 y 25 años.");
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Edad no valida.");
            return;
        }
        if (nombreNuevo.isEmpty() || descripcionNueva.isEmpty() || generoNuevo.isEmpty() || edadNueva.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Complete todos los campos para actualizar.");
            return;
        }

        Document filtro = new Document("Nombre", nombreAntiguo);
        Document actualizacion = new Document("$set", new Document()
                .append("Nombre", nombreNuevo)
                .append("Genero", generoNuevo)
                .append("Edad", edadNueva)
                .append("Descripcion", descripcionNueva)
        );

        if (mongo.actualizar2(filtro, actualizacion)) {
            JOptionPane.showMessageDialog(view, "Registro de mascota actualizado correctamente.", "Actualizacion exitosa", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos(); // Limpieza después de actualizar
            cargarRegistrosTabla();
        } else {
            JOptionPane.showMessageDialog(view, "Error al actualizar el registro.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarRegistrosTabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) view.tablaDatos1.getModel();
        modeloTabla.setRowCount(0);

        List<Document> registros = mongo.lista(new Document());
        for (Document doc : registros) {
            Object[] fila = new Object[]{
                doc.getString("Nombre"),
                doc.getString("Genero"),
                doc.getString("Edad"),
                doc.getString("Descripcion")
            };
            modeloTabla.addRow(fila);
        }
    }

    // Selector y guardado de imagen
    private void seleccionarImagen() {
        try {
            String nombreMascota = view.txtNombre1.getText().trim();
            if (nombreMascota.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Primero ingresa el NOMBRE de la mascota.");
                return;
            }

            Files.createDirectories(baseImgDir);

            JFileChooser fc = new JFileChooser();
            fc.setFileFilter(new FileNameExtensionFilter("Imágenes (JPG, PNG, GIF)", "jpg", "jpeg", "png", "gif"));
            int r = fc.showOpenDialog(view);
            if (r != JFileChooser.APPROVE_OPTION) {
                return;
            }

            File src = fc.getSelectedFile();
            String ext = getExtension(src.getName());
            if (ext == null) {
                JOptionPane.showMessageDialog(view, "Archivo sin extensión válida.");
                return;
            }

            // Carpeta para mascota, nombre normalizado
            String nombreSan = normalizar(nombreMascota);
            Path carpetaMascota = baseImgDir.resolve(nombreSan);
            Files.createDirectories(carpetaMascota);

            // Nombre único con timestamp
            String nombreArchivo = nombreSan + "_" + System.currentTimeMillis() + "." + ext.toLowerCase();
            Path dest = carpetaMascota.resolve(nombreArchivo);

            Files.copy(src.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);

            JOptionPane.showMessageDialog(view, "Imagen copiada a: " + dest.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(view, "Error al cargar/copiar la imagen: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static String getExtension(String filename) {
        int i = filename.lastIndexOf('.');
        if (i > 0 && i < filename.length() - 1) {
            return filename.substring(i + 1);
        }
        return null;
    }

    private static String normalizar(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        n = n.replaceAll("[^a-zA-Z0-9-_]", "_");
        return n.toLowerCase();
    }

    private void irAVistaInicioSesion() {
        view.dispose(); // Cierra la ventana actual
        VistaInicioSesion vistaInicio = new VistaInicioSesion();
        ControladorInicioSesion ctrlInicio = new ControladorInicioSesion(vistaInicio);
        ctrlInicio.iniciarVista();
    }

    public void irSolicitudes() {
        VistaSolicitudes view2 = new VistaSolicitudes();
        ControladorSolicitudes controlSoli = new ControladorSolicitudes(view2);
        controlSoli.iniciar();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btnSave1) {
            guardarRegistro();
        } else if (e.getSource() == view.btnClean1) {
            limpiarCampos();
        } else if (e.getSource() == view.btnUpdateUribe) {
            actualizarRegistro();
        } else if (e.getSource() == view.btnImagen) {
            seleccionarImagen();
        } else if (e.getSource() == view.btnExit2) {
            irAVistaInicioSesion();
        } else if (e.getSource() == view.btnSolicitudes) {
            irSolicitudes();
        }
    }
}
