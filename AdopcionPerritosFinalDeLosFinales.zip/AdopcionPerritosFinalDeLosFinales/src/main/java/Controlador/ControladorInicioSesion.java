
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ConexionMongo;
import Modelo.ModeloRegistro;
import Vista.Adopcion;
import Vista.VistaInicioSesion;
import Vista.VistaRegistro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import org.bson.Document;

/**
 *
 * @author espe
 */
public class ControladorInicioSesion implements ActionListener {

    VistaInicioSesion view = new VistaInicioSesion();
    ConexionMongo mongo = new ConexionMongo();

    public ControladorInicioSesion(VistaInicioSesion view) {
        this.view = view;
        this.mongo = new ConexionMongo();
        view.btnIngresar.addActionListener(this);
        view.btnRegistrar.addActionListener(this);
        view.btnSalir.addActionListener(this);
        view.btnCancelar.addActionListener(this);
        crearUsuarioPorDefecto();
    }

    private void crearUsuarioPorDefecto() {
        Document filtro = new Document("Usuario", "admin");
        Document existente = mongo.buscar(filtro);

        if (existente == null) {
            Document admin = new Document("Usuario", "admin")
                    .append("Apellido", "admin")
                    .append("Categoria", "Administrador")
                    .append("Clave", "admin")
                    .append("Correo", "admin@espe.edu.ec");

            boolean guardado = mongo.guardar(admin);
            if (guardado) {
                System.out.println("Usuario por defecto 'admin' creado exitosamente.");
            } else {
                System.out.println("Error al crear el usuario por defecto.");
            }
        } else {
            System.out.println("Usuario 'admin' ya existe. No se crea nuevamente.");
        }
    }

    public void iniciarVista() {
        view.setVisible(true);
        limpiar();
    }

    public void MetodoIngreso() {
        String usuarioConsulta = view.txtUsuario.getText();
        String claveConsulta = view.txtClave.getText();

        // Validaciones
        if (usuarioConsulta.isEmpty() || claveConsulta.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            return;
        }

        Document filtro = new Document("Usuario", usuarioConsulta).append("Clave", claveConsulta);
        Document resultado = mongo.buscar(filtro);

        if (resultado != null) {
            JOptionPane.showMessageDialog(view, "Inicio de sesion exitoso. Bienvenido " + usuarioConsulta + "!");
            ModeloRegistro.datosUsuario = resultado;
            // Verificar si es el usuario admin
            if (usuarioConsulta.equals("admin") && claveConsulta.equals("admin")) {
                // Abrir la vista para el administrador
                VistaRegistro vistaRegistro = new VistaRegistro();
                ControladorRegistro controladorRegistro = new ControladorRegistro(vistaRegistro);
                controladorRegistro.iniciarVista();
            } else {
                // Abrir la vista normal para los usuarios (clientes)
                Adopcion view2 = new Adopcion();
                ControladorAdopcion adopcion = new ControladorAdopcion(view2);
                adopcion.iniciarVista();
            }

            limpiar();
            view.dispose();

        } else {
            JOptionPane.showMessageDialog(view, "Usuario o clave incorrectos.");
        }
    }

    public void limpiar() {
        // Campos del login
        view.txtUsuario.setText("");
        view.txtClave.setText("");

        // Campos del registro
        view.txtNombre.setText("");
        view.txtApellido.setText("");
        view.txtClaveR.setText("");
        view.txtCorreoR.setText("");
    }

    public void MetodoRegistro() {
        String usuario = view.txtNombre.getText();
        String apellido = view.txtApellido.getText();
        String clave = view.txtClaveR.getText();
        String correo = view.txtCorreoR.getText();
        if (usuario.isEmpty() || apellido.isEmpty() || clave.isEmpty() || correo.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Por favor, complete todos los campos.");
            return;
        }
        if (!correo.matches("^[\\w._%+-]+@espe\\.edu\\.ec$")) {
            JOptionPane.showMessageDialog(view, "El correo ingresado debe pertenecer al dominio @espe.edu.ec.", "Correo invalido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Document filtro = new Document("Usuario", usuario);
        Document existente = mongo.buscar(filtro);

        if (existente != null) {
            JOptionPane.showMessageDialog(view, "El usuario ya existe. Elija otro nombre de usuario.", "Registro duplicado", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Document nuevoUsuario = new Document("Usuario", usuario)
                .append("Apellido", apellido)
                .append("Categoria", "Cliente")
                .append("Clave", clave)
                .append("Correo", correo);

        boolean guardado = mongo.guardar(nuevoUsuario);

        if (guardado) {
            JOptionPane.showMessageDialog(view, "Registro exitoso. Ahora puede iniciar sesion.", "Registro completado", JOptionPane.INFORMATION_MESSAGE);
            limpiar();
        } else {
            JOptionPane.showMessageDialog(view, "Error al registrar el usuario. Intente nuevamente.", "Error de registro", JOptionPane.ERROR_MESSAGE);
            //limpiar();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btnIngresar) {
            MetodoIngreso();
        } else if (e.getSource() == view.btnRegistrar) {
            MetodoRegistro();
        } else if (e.getSource() == view.btnSalir) {
            System.exit(0);
        } else if (e.getSource() == view.btnCancelar) {
            limpiar();
        } else {
            System.out.println("Accion desconocida");
        }
    }

}
