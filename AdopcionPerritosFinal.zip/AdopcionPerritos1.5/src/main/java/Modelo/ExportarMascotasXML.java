package Modelo;

import java.util.List;
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Element;
import org.w3c.dom.Document; // Para XML DOM
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class ExportarMascotasXML {

    public static void exportar(List<org.bson.Document> mascotas, String nombreArchivo) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();

            // Elemento raíz
            Element root = doc.createElement("Mascotas");
            doc.appendChild(root);

            // Itera sobre cada mascota
            for (org.bson.Document pet : mascotas) {
                Element mascota = doc.createElement("Mascota");

                mascota.setAttribute("nombre", pet.getString("Nombre"));
                mascota.setAttribute("genero", pet.getString("Genero"));
                mascota.setAttribute("edad", pet.getString("Edad"));

                Element descripcion = doc.createElement("Descripcion");
                descripcion.setTextContent(pet.getString("Descripcion"));
                mascota.appendChild(descripcion);

                root.appendChild(mascota);
            }

            // Escribir archivo XML
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(nombreArchivo));
            transformer.transform(source, result);

            System.out.println("Archivo XML creado correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
