/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import org.bson.Document;

/**
 *
 * @author espe
 */
public class ModeloRegistro {
    String nombre, genero, descripcion, edad;
public static Document datosUsuario = null;
    public ModeloRegistro(String nombre, String genero, String descripcion, String edad) {
        this.nombre = nombre;
        this.genero = genero;
        this.descripcion = descripcion;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "ModeloRegistro{" + "nombre=" + nombre + ", genero=" + genero + ", descripcion=" + descripcion + ", edad=" + edad + '}';
    }
    
}
