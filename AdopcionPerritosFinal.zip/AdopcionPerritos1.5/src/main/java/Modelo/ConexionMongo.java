package Modelo;

import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.UpdateResult;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;

public class ConexionMongo {

    private final String url = "mongodb://localhost:27017";
    private final String dataBase = "ESPE";
    private MongoClient cliente;
    private MongoDatabase mongo;
    private MongoCollection<Document> coleccion;

    // Constructor general: permite elegir la coleccion
    public ConexionMongo(String nombreColeccion) {
        cliente = MongoClients.create(url);
        mongo = cliente.getDatabase(dataBase);

        boolean existe = mongo.listCollectionNames()
                .into(new ArrayList<>())
                .contains(nombreColeccion);

        if (!existe) {
            mongo.createCollection(nombreColeccion);
            System.out.println("Coleccion '" + nombreColeccion + "' creada.");
        }

        coleccion = mongo.getCollection(nombreColeccion);
        System.out.println("Conexion establecida correctamente con la coleccion: " + nombreColeccion);
    }

    // Constructor por defecto: sigue usando CentroDeAdopcion
    public ConexionMongo() {
        this("CentroDeAdopcion");
    }

    public boolean guardar(Document doc) {
        coleccion.insertOne(doc);
        System.out.println("Documento guardado correctamente en " + coleccion.getNamespace().getCollectionName());
        return true;
    }

    public List<Document> lista(Document filtro) {
        List<Document> resultado = coleccion.find(filtro).into(new ArrayList<>());
        System.out.println("Documentos encontrados: " + resultado);
        return resultado;
    }

    public boolean actualizar(Document filtro, Document nuevosDatos) {
        coleccion.updateOne(filtro, new Document("$set", nuevosDatos));
        System.out.println("Documento actualizado correctamente.");
        return true;
    }
    // Clase ConexionMongo

    public boolean actualizar2(Document filtro, Document actualizacion) {
        try {
            // Asegúrate de que 'coleccion' sea tu MongoCollection<Document>
            UpdateResult resultado = coleccion.updateOne(filtro, actualizacion);
            return resultado.getModifiedCount() > 0; // Retorna true si se actualizó algún documento
        } catch (MongoWriteException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(Document filtro) {
        coleccion.deleteOne(filtro);
        System.out.println("Documento eliminado correctamente.");
        return true;
    }

    public void cerrar() {
        cliente.close();
        System.out.println("Conexion cerrada.");
    }

    public Document buscar(Document filtro) {
        Document resultado = coleccion.find(filtro).first();

        if (resultado != null) {
            System.out.println("Documento encontrado: " + resultado.toJson());
        } else {
            System.out.println("No se encontro ningun documento con ese filtro.");
        }
        return resultado;
    }
}
