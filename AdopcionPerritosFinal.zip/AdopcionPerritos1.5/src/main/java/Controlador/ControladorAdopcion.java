package Controlador;

import Vista.Adopcion;
import Modelo.ConexionMongo;
import Modelo.ModeloRegistro;
import org.bson.Document;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.ImageIcon;
import java.nio.file.*;
import java.io.File;
import java.util.Arrays;

import Vista.VistaInicioSesion;

public class ControladorAdopcion {

    private Adopcion viewAdopcion;
    private final Path baseImgDir = Paths.get(System.getProperty("user.dir"), "imagenes_mascotas"); // Directorio base de imágenes
    private ConexionMongo mongo;

    public ControladorAdopcion(Adopcion viewAdopcion) {
        this.viewAdopcion = viewAdopcion;
        this.mongo = new ConexionMongo("RegistroMascotas");

        cargarMascotasTabla();

        this.viewAdopcion.jTable1.getSelectionModel().addListSelectionListener(
                (ListSelectionListener) e -> {
                    if (!e.getValueIsAdjusting()) {
                        int row = this.viewAdopcion.jTable1.getSelectedRow();
                        if (row >= 0) {
                            mostrarInformacionMascota(row);
                            mostrarImagenMascota(row); // Mostrar imagen en el label
                        } else {
                            limpiarImagenMascota();
                        }
                    }
                }
        );
        this.viewAdopcion.btnSave1.addActionListener(e -> postularMascota());
        // Listener para volver a menú de inicio
        this.viewAdopcion.btnSave2.addActionListener(e -> retornarAVistaInicioSesion());
    }

    public void iniciarVista() {
        viewAdopcion.setVisible(true);
        cargarMascotasTabla();
    }

    private void cargarMascotasTabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) viewAdopcion.jTable1.getModel();
        modeloTabla.setRowCount(0);

        List<Document> mascotas = mongo.lista(new Document());

        for (Document doc : mascotas) {
            Object[] fila = new Object[]{
                doc.getString("Nombre"),
                doc.getString("Edad"),
                doc.getString("Genero")
            };
            modeloTabla.addRow(fila);
        }

        viewAdopcion.jTextField1.setText("");
        limpiarImagenMascota();
    }

    // SOLO descripción en el jTextField1
    private void mostrarInformacionMascota(int filaSeleccionada) {
        if (filaSeleccionada < 0) {
            return;
        }

        String nombre = String.valueOf(viewAdopcion.jTable1.getValueAt(filaSeleccionada, 0));
        Document filtro = new Document("Nombre", nombre);
        Document doc = mongo.buscar(filtro);

        if (doc != null) {
            viewAdopcion.jTextField1.setText(doc.getString("Descripcion") != null ? doc.getString("Descripcion") : "");
        } else {
            viewAdopcion.jTextField1.setText("");
        }
    }

    // Mostrar imagen de mascota según nombre/carpeta
    private void mostrarImagenMascota(int filaSeleccionada) {
        if (filaSeleccionada < 0) {
            limpiarImagenMascota();
            return;
        }
        String nombre = String.valueOf(viewAdopcion.jTable1.getValueAt(filaSeleccionada, 0));
        String nombreSan = normalizar(nombre);
        Path carpetaMascota = baseImgDir.resolve(nombreSan);

        if (Files.exists(carpetaMascota) && Files.isDirectory(carpetaMascota)) {
            File folder = carpetaMascota.toFile();
            File[] archivos = folder.listFiles((dir, name) -> name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".gif"));
            if (archivos != null && archivos.length > 0) {
                // Tomamos la imagen más reciente (opcional puedes elegir la primera)
                Arrays.sort(archivos, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                File imagen = archivos[0];
                ImageIcon icon = new ImageIcon(imagen.getAbsolutePath());
                // Opcional: redimensionar imagen al tamaño del JLabel
                int lblW = viewAdopcion.lblImagenMascota.getWidth();
                int lblH = viewAdopcion.lblImagenMascota.getHeight();
                ImageIcon scaledIcon = new ImageIcon(icon.getImage().getScaledInstance(lblW, lblH, java.awt.Image.SCALE_SMOOTH));
                viewAdopcion.lblImagenMascota.setIcon(scaledIcon);
            } else {
                limpiarImagenMascota(); // No hay imagen
            }
        } else {
            limpiarImagenMascota(); // No existe carpeta para la mascota
        }
    }

    // Limpia el JLabel de la imagen
    private void limpiarImagenMascota() {
        viewAdopcion.lblImagenMascota.setIcon(null);
    }

    private void postularMascota() {
        int filaSeleccionada = viewAdopcion.jTable1.getSelectedRow();
        if (filaSeleccionada == -1) {
            javax.swing.JOptionPane.showMessageDialog(viewAdopcion, "Selecciona una mascota para postularte.");
            return;
        }

        String descripcion = viewAdopcion.jTextField1.getText();

        String mensaje = "¡Postulación enviada correctamente!\n\n"
                + "Los datos de tu postulación han sido enviados a tu correo electrónico.\n\n"
                + "Descripción de la mascota postulada:\n"
                + descripcion;

        javax.swing.JOptionPane.showMessageDialog(viewAdopcion, mensaje, "Postulación completada", javax.swing.JOptionPane.INFORMATION_MESSAGE);
         guardarSolicitudAdopcion();
        viewAdopcion.jTextField1.setText("");
        limpiarImagenMascota();
    }

    // Volver a interfaz de inicio de sesión
    private void retornarAVistaInicioSesion() {
        viewAdopcion.dispose();
        VistaInicioSesion vista = new VistaInicioSesion();
        ControladorInicioSesion controlador = new ControladorInicioSesion(vista);
        controlador.iniciarVista();
    }

    // Normalizador de nombre para carpeta
    private static String normalizar(String s) {
        String n = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        n = n.replaceAll("[^a-zA-Z0-9-_]", "_"); // Reemplaza espacios y caracteres raros por _
        return n.toLowerCase();
    }

private void guardarSolicitudAdopcion() {
    int filaSeleccionada = viewAdopcion.jTable1.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(viewAdopcion, "Selecciona una mascota para postularte.");
        return;
    }
    String nombre = String.valueOf(viewAdopcion.jTable1.getValueAt(filaSeleccionada, 0));
    String edad = String.valueOf(viewAdopcion.jTable1.getValueAt(filaSeleccionada, 1));
    String genero = String.valueOf(viewAdopcion.jTable1.getValueAt(filaSeleccionada, 2));
    String descripcion = viewAdopcion.jTextField1.getText();

    org.bson.Document userDoc = ModeloRegistro.datosUsuario;

    ConexionMongo mongoSolicitudes = new ConexionMongo("registroSolicitudes");

    org.bson.Document nuevaSolicitud = new org.bson.Document()
        .append("NombreMascota", nombre)
        .append("EdadMascota", edad)
        .append("GeneroMascota", genero)
        .append("DescripcionMascota", descripcion)
        // DATOS DEL POSTULANTE:
        .append("Usuario", userDoc.getString("Usuario"))
        .append("Apellido", userDoc.getString("Apellido"))
        .append("Correo", userDoc.getString("Correo"))
        .append("Categoria", userDoc.getString("Categoria"))
        .append("Fecha", new java.util.Date());

    if (mongoSolicitudes.guardar(nuevaSolicitud)) {
        System.out.println("Solicitud guardada correctamente en registroSolicitudes.");
    } else {
        System.out.println("Error al guardar la solicitud.");
    }
}


}
