package Controlador;

import Vista.VistaSolicitudes;
import Modelo.ConexionMongo;
import org.bson.Document;

import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorSolicitudes {
    private VistaSolicitudes view;
    private ConexionMongo mongoSolicitudes;

    public ControladorSolicitudes(VistaSolicitudes view) {
        this.view = view;
        this.mongoSolicitudes = new ConexionMongo("registroSolicitudes");

        this.view.btnAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                aceptarSolicitud();
            }
        });
        this.view.btnRechazar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rechazarSolicitud();
            }
        });
        this.view.btnRegresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                regresar();
            }
        });
    }

    public void iniciar() {
        view.setVisible(true);
        cargarSolicitudesTabla();
    }

    private void cargarSolicitudesTabla() {
        DefaultTableModel modeloTabla = (DefaultTableModel) view.tablaSolicitudes.getModel();
        modeloTabla.setRowCount(0);

        List<Document> solicitudes = mongoSolicitudes.lista(new Document());

        for (Document doc : solicitudes) {
            Object[] fila = new Object[]{
                doc.getString("NombreMascota"),
                doc.getString("EdadMascota"),
                doc.getString("GeneroMascota"),
                doc.getString("DescripcionMascota"),
                doc.getString("Usuario"),
                doc.getString("Apellido"),
                doc.getString("Correo"),
                doc.get("Fecha") != null ? doc.get("Fecha").toString() : ""
            };
            modeloTabla.addRow(fila);
        }
    }

    private void limpiarSeleccion() {
        view.tablaSolicitudes.clearSelection();
    }

    private void aceptarSolicitud() {
        int fila = view.tablaSolicitudes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(view, "Selecciona una solicitud para aceptar.");
            return;
        }
        String nombreMascota = String.valueOf(view.tablaSolicitudes.getValueAt(fila, 0));
        String usuario = String.valueOf(view.tablaSolicitudes.getValueAt(fila, 4));

        Document filtro = new Document("NombreMascota", nombreMascota)
                          .append("Usuario", usuario);
        if (mongoSolicitudes.eliminar(filtro)) {
            JOptionPane.showMessageDialog(view, "Solicitud aceptada y notificacion al postulante en curso.");
            cargarSolicitudesTabla();
            limpiarSeleccion();
        } else {
            JOptionPane.showMessageDialog(view, "No se pudo eliminar la solicitud.");
        }
    }

    private void rechazarSolicitud() {
        int fila = view.tablaSolicitudes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(view, "Selecciona una solicitud para rechazar.");
            return;
        }
        String nombreMascota = String.valueOf(view.tablaSolicitudes.getValueAt(fila, 0));
        String usuario = String.valueOf(view.tablaSolicitudes.getValueAt(fila, 4));

        Document filtro = new Document("NombreMascota", nombreMascota)
                          .append("Usuario", usuario);
        if (mongoSolicitudes.eliminar(filtro)) {
            JOptionPane.showMessageDialog(view, "Solicitud rechazada y eliminada de la lista.");
            cargarSolicitudesTabla();
            limpiarSeleccion();
        } else {
            JOptionPane.showMessageDialog(view, "No se pudo eliminar la solicitud.");
        }
    }

    private void regresar() {
        view.dispose();
    }
}
