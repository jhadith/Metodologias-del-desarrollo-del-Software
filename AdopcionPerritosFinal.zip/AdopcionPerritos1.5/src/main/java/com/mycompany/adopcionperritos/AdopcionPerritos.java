/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.adopcionperritos;

import Controlador.ControladorInicioSesion;
import Controlador.ControladorRegistro;
import Vista.VistaInicioSesion;
import Vista.VistaRegistro;

/**
 *
 * @author espe
 */
public class AdopcionPerritos {

   public static void main(String[] args) {
    VistaInicioSesion vista = new VistaInicioSesion();
    ControladorInicioSesion controlador = new ControladorInicioSesion(vista);
    controlador.iniciarVista();
}
}
